
***************
file name: ENCFF643FMK.bam
file encode accession: ENCFF643FMK
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF643FMK/@@download/ENCFF643FMK.bam
output category: alignment
output type: alignments
assembly: GRCh38

***************
file name: ENCFF956FPT_peaks_GRCh38.bed.gz
file encode accession: ENCFF956FPT
status: released
file format: bed
file type: bed narrowPeak
file size: 449702
md5sum: 615e90c89c2834d908e7a4d88655131e
content md5sum: 98709cbf3991b4063912e42e36f573cd
output category: annotation
output type: peaks
assembly: GRCh38
derived from: ENCFF813FWF; ENCFF643FMK.bam

***************
file name: ENCFF374BHV_signal_of_unique_reads_GRCh38.bigWig
file encode accession: ENCFF374BHV
status: released
file format: bigWig
file type: bigWig
file size: 251709800
md5sum: dfdaae28ac4dce107ccd4bfb2c1a1cfd
output category: signal
output type: signal of unique reads
assembly: GRCh38
derived from: ENCFF643FMK.bam
