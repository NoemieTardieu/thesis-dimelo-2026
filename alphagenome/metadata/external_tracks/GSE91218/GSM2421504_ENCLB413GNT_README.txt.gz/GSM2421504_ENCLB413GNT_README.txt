
***************
file name: ENCFF973TUQ.bam
file encode accession: ENCFF973TUQ
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF973TUQ/@@download/ENCFF973TUQ.bam
output category: alignment
output type: alignments
assembly: GRCh38

***************
file name: ENCFF404REU_peaks_GRCh38.bed.gz
file encode accession: ENCFF404REU
status: released
file format: bed
file type: bed narrowPeak
file size: 519824
md5sum: 3c2b5268266aeb475018875a1aa04f3d
content md5sum: 08454cedaed399762e1bde962d0a43c3
output category: annotation
output type: peaks
assembly: GRCh38
derived from: ENCFF159VBZ; ENCFF973TUQ.bam

***************
file name: ENCFF997ANB_signal_of_unique_reads_GRCh38.bigWig
file encode accession: ENCFF997ANB
status: released
file format: bigWig
file type: bigWig
file size: 337497622
md5sum: f56230929013bf4d075a8ff71157c48e
output category: signal
output type: signal of unique reads
assembly: GRCh38
derived from: ENCFF973TUQ.bam
