
***************
file name: ENCFF428UWO.bam
file encode accession: ENCFF428UWO
status: released
file format: bam
file type: bam
href: https://www.encodeproject.org/files/ENCFF428UWO/@@download/ENCFF428UWO.bam
output category: alignment
output type: alignments
assembly: GRCh38

***************
file name: ENCFF857ZRY_peaks_GRCh38.bed.gz
file encode accession: ENCFF857ZRY
status: released
file format: bed
file type: bed narrowPeak
file size: 461006
md5sum: 2961ba77121e6ee21fd1b8f9e31a9252
content md5sum: b0e5db0b68354c8c95e08c5fe4e14d4d
output category: annotation
output type: peaks
assembly: GRCh38
derived from: ENCFF236QYF; ENCFF428UWO.bam

***************
file name: ENCFF987FCK_signal_of_unique_reads_GRCh38.bigWig
file encode accession: ENCFF987FCK
status: released
file format: bigWig
file type: bigWig
file size: 254012946
md5sum: 1bde888d37a6155486c909686e979e00
output category: signal
output type: signal of unique reads
assembly: GRCh38
derived from: ENCFF428UWO.bam
